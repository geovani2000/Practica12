using System;
using Microsoft.AspNetCore.Mvc;

namespace Practica_12.Controllers
{
    public class AreaController : Controller
    {
        public IActionResult Area()
        {
            return View();
        }

       [HttpPost]
        public ActionResult Area (string numero1, string numero2, string tipo)
        {
            int a = Convert.ToInt32(numero1);
            int b = Convert.ToInt32(numero2);
            int c = 0;
            if(tipo=="Rectangulo")
            {
                c=a*b;
                ViewBag.Result = c;
            }
            else if (tipo=="triangulo")
            {
                c=a*b/2;
             ViewBag.Result = c;
            }

            else{
                ViewBag.Result = c;
            }
            
            return View();


        }
    }
}

